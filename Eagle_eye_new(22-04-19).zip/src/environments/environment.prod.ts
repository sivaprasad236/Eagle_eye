declare var baseUrl: any;

export const environment = {
  production: true,
  API_URL: baseUrl,
};
