export interface DashboardMenu {
    _id: string;
    created_date: string;
    descripton: string;
    project_name: string;
    project_type: string;  
}