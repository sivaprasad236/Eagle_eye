export interface ProjectTypeModel {
    business_name : String;
}