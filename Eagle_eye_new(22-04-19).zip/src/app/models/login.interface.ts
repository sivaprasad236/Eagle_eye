export interface User {
    User_ID: string;
    Password: string;
  }