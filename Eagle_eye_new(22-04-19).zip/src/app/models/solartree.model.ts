export class Catagory {
    docId?: string;
    name?: string;
    children?: Catagory[];
}