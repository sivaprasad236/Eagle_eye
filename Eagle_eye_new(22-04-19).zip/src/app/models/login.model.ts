export class LoginModel {
    File_Name: string;
    Latitude: number;
    Longitude: number;
    _id: string;
}