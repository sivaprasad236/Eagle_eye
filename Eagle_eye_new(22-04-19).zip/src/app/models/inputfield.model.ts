export class InputUnIdentified{
    _id: string;
    user_input: string;

    constructor(_id: string, user_input: string){
        this._id = _id;
        this.user_input = user_input;
    }
}