export interface UploadFile {
  Project: string;
  Plant: string;
}