export class DataService{
    dataFromService;
}