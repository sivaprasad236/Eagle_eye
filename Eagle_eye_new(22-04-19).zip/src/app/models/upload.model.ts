export interface UploadModel {
    Date: string;
    Folder_Name: string;
    Project: string;
    Status: string;
    Type: string;
    image_type: string;
    plot: string;
}