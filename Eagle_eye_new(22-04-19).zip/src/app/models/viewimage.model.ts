export interface DisplayImageModel {
    Image_url: string;
    _id: string;
}